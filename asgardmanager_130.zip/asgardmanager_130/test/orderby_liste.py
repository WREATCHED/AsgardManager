liste = [(19581, 'aa', False, False), (18973, 'consult.defaut', True, False), (19579, 'didier.aecle', True, False), (19583, 'didier.leclerc', True, True), (19056, 'etienne.lousteau', True, False),(18000,"bbbb",True,False)]
print(liste)
l =  [ [ee[1].split("."),ee] for ee in [ e for e in liste ] ]
print(l)
l = [ [ [eee[0][len(eee[0]) - 1 ] ], eee[1] ] for eee in l ]
print(l)


l = [ [ [("1" if eee[1][2] else "2") + eee[0][len(eee[0]) - 1 ] ], eee[1] ] for eee in [ [ee[1].split("."),ee] for ee in [ e for e in liste ] ] ]
print(l)
ll = [l[1] for l in sorted(l, key=lambda colonnes: colonnes[0], reverse = False)]
print(ll)
#◘mListRoleGroupMembreComplet = sorted([ [eee[0][len(eee[0]) - 1 ], eee[1] ] for eee in [ [ee[1].split("."),ee] for ee in [ e for e in mListRoleGroupMembreComplet ] ] ])
