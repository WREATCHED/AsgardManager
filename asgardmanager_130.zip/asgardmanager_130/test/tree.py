import sys
from PyQt5.Qt import *

class MyWindow(QTreeWidget):
    def __init__(self, *args):
        QTreeWidget.__init__(self, *args)

        self.setColumnCount(1)
        self.insertTopLevelItems( 0, [ QTreeWidgetItem(None, [ "Tables" ] ) ] )
        
        root = self.topLevelItem( 0 )

        for i in range(10):
            node = QTreeWidgetItem(None, [ "Item" + str(i) ] )
            root.addChild( node )
        
        self.itemDoubleClicked.connect( self.processItem )
        
        
    def processItem(self, item, column):
        print( ">>> " + str(item) + " - " + item.data(column, Qt.DisplayRole) )


if __name__ == "__main__" :
    app = QApplication( sys.argv )

    myWindow = MyWindow()
    myWindow.show()
    
    sys.exit( app.exec_() )