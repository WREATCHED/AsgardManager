from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import (QAction, QMenu , QApplication, QMessageBox, QFileDialog, QTextEdit, QMainWindow) 
 
from PyQt5.QtCore import *
from PyQt5.QtGui import QIcon
from PyQt5.QtGui import *

from qgis.core import QgsProject, QgsMapLayer, QgsVectorLayerCache, QgsFeatureRequest, QgsSettings, QgsDataSourceUri 
from qgis.utils import iface
import psycopg2

def listBase():
    mSettings = QSettings()
    mSettings.beginGroup("/PostgreSQL/connections")
    mListeBase = mSettings.childGroups()
    return mListeBase

#========================================================
class BASEPOSTGRES :
    #----------------------
    def __init__(self, nameBase):
        self.nameBase = nameBase
        mSettings = QSettings()
        mSettings.beginGroup("/PostgreSQL/connections/{}".format(self.nameBase))
        if not mSettings.contains("database") :
           QMessageBox.critical(self, "Error", "There is no defined database connection")
           mListConnectBase = []
        else :
           settingsList = ["service", "host", "port", "database", "username", "password"]
           self.service, self.host, self.port, self.database, self.username, self.password = map(lambda x: mSettings.value(x, "", type=str), settingsList)
           mListConnectBase = [self.service, self.host, self.port, self.database, self.username, self.password ]
        mSettings.endGroup()
        
        self.nameBasemListConnectBase = mListConnectBase
        #return self.nameBasemListConnectBase
    #----------------------
    def connectBase(self) :
        print("affiche service : " + str(self.service))
        mSettings = QSettings()
        mSettings.beginGroup("/PostgreSQL/connections/{}".format(self))
        uri = QgsDataSourceUri()
        useEstimatedMetadata = mSettings.value("estimatedMetadata", False, type=bool)
        uri.setUseEstimatedMetadata(useEstimatedMetadata)
        self.sslmode = uri.decodeSslMode(mSettings.value("sslmode"))
        print("SSLMODE : " + str(self.sslmode) )

        try :
           if self.service:
              print("Yes Service")
              mConfigConnection = "service{0} dbname={1} user={2} password={3} sslmode={4}".format(self.service, self.database, self.username, self.password, self.sslmode)
              mConfigConnection = "service{0} dbname={1} user={2} password={3} sslmode={4}".format(self.service, self.database, self.username, self.password)
              mConnectEnCours = psycopg2.connect(mConfigConnection)
           else:
              print("No Service")
              mConfigConnection = "host={0} port={1} dbname={2} user={3} password={4} sslmode={5}".format(self.host, self.port, self.database, self.username, self.password, self.sslmode)
              mConfigConnection = "host={0} port={1} dbname={2} user={3} password={4} ".format(self.host, self.port, self.database, self.username, self.password)
              mConnectEnCours = psycopg2.connect(mConfigConnection)
           self.mConnectEnCours = mConnectEnCours
           self.mConnectEnCoursPointeur = mConnectEnCours.cursor()
           return True, self.mConnectEnCours
        except :
           QMessageBox.warning(None,"ASGARD : Connection","La connection est impossible")
           return False, None
        mSettings.endGroup()
    #----------------------
    def executeSql(self,pointeurBase, mSql) :
        pointeurBase.execute(mSql)
        result = pointeurBase.fetchall()
        return result
     #----------------------
    def deconnectBase(self) :
        self.mConnectEnCours.commit()
        self.mConnectEnCoursPointeur.close()
        self.mConnectEnCours.close()
        return 
     #----------------------
    def layerPostgresql(self, mName, mSchema, mSource, mSql, mProvider ) :
        #try :
           if self.service :
              QMessageBox.warning(None,"ASGARD : Connection","La connection est impossible")
              return False, None
           else:
              uri = QgsDataSourceUri()             
              uri.setConnection(self.host, self.port, self.database, self.username, self.password)
              uri.setDataSource(mSchema, mSource, "geom",mSql)
              vlayer = QgsVectorLayer(uri.uri(), mName, mProvider)
              return True, vlayer        
        #except :
           QMessageBox.warning(None,"ASGARD : Connection","La connection est impossible")
           return False, None

#==================================================
def openShowTableAttributeSelected(attributBar):
    mQSettings = QSettings()
    oldValueOpenAttribut = mQSettings.value("qgis/attributeTableBehavior")
    mQSettings.setValue("qgis/attributeTableBehavior","ShowSelected")
    myValueButtonAttribut = returnValueOpenShowTableAttribute(attributBar)
    attributBar.children()[myValueButtonAttribut].actions()[0].trigger()
    mQSettings.setValue("qgis/attributeTableBehavior",oldValueOpenAttribut)         

#==================================================
def returnValueOpenShowTableAttribute(attributBar):
   valueReturnOpenShowTableAttribute = 5 #Value Default
   ii = 0  
   chsBar  = attributBar.children()
   
   for ii in range(len(chsBar)) :
       try :
          if chsBar[ii].actions()[0].objectName() == "mActionOpenTable" :
             valueReturnOpenShowTableAttribute = ii
             break
       except :
          pass
          
       ii += 1
   return valueReturnOpenShowTableAttribute
   
#==================================================

def field_readonly(layer, fieldname, option = True):
    fields = layer.fields()
    field_idx = fields.indexOf(fieldname)
    if field_idx >= 0:
        form_config = layer.editFormConfig()
        form_config.setReadOnly(field_idx, option)
        layer.setEditFormConfig(form_config)
"""
project = QgsProject.instance()
layers = project.mapLayers() 
#---------------
for layer in layers.values():
    a = field_readonly(layer,'type')
    print(str(a))
"""    
#==================================================
"""
PARTIE TEST POSTGRESQL QgsDataSourceUri()    
mIface = iface
#mIfaceActive = mIface.activeLayer()

mySource = "D:\\Divers_test\\camino\\titres-m-ar-dmc.geojson"
fluxTitre = "Didier"
fluxProvider = "ogr"
vlayer = QgsVectorLayer(mySource, fluxTitre, fluxProvider)

#-------------------
for i in range(len(listBase())):
    lNameBase = listBase()[i]
    print(lNameBase)
    print(BASEPOSTGRES(lNameBase)) 

mBaseAsgard = BASEPOSTGRES(listBase()[0]) 
mySchema = "z_asgard"   
mySource = "monschemadidier"
fluxTitre = "Didier gestion_schema_usr"
fluxProvider = "postgres"
mySql = ""
mlayer = mBaseAsgard.layerPostgresql(fluxTitre, mySchema, mySource, mySql, fluxProvider )
print(mlayer)
if mlayer[0]:
   vlayer = mlayer[1]
   print(str(vlayer))
   print("a")
   QgsProject.instance().addMapLayer(vlayer)
   print("b")
#-------------------
"""
   
mIfaceActive = vlayer
iface.setActiveLayer(mIfaceActive)

expression  = "nature = 'Station de traitement'"
expression  = "srid > 2900 and srid < 3000"
expression  = "niv1 = 'agriculture' or niv1 = 'air_climat'"

request = QgsFeatureRequest().setFilterExpression(expression)
print(mIfaceActive.name())
mIfaceFilter = mIfaceActive.getFeatures(request)
mIfaceActive.select([k.id() for k in mIfaceFilter])
attributBar = mIface.attributesToolBar()
iface.showAttributeTable(mIfaceActive)

#openShowTableAttributeSelected(attributBar)

#retour liste base pp
def asgardPostgresql() :
    print(listBase()) 

    for i in range(len(listBase())):
        lNameBase = listBase()[i]
        print(lNameBase)
        print(BASEPOSTGRES(lNameBase)) 

    mBaseAsgard = BASEPOSTGRES(listBase()[0])    
    connectBaseAsgard= mBaseAsgard.connectBase()
    print(connectBaseAsgard)
    if connectBaseAsgard[0] :
       dicMySql = {}
       dicMySql["mSql1"] = (
           """
           SELECT "gestion_schema_usr".* 
           FROM "z_asgard"."gestion_schema_usr"
           """
           ,
           "LISTE VUE GESTION_SCHEMA_USR")
       dicMySql["mSql2"] = (
           """
           SELECT nspname
           FROM pg_namespace
           WHERE nspname not ilike 'pg_%'
           and nspname not in ('pg_catalog', 'information_schema')
           """
           ,
           "LISTE DES SCHEMAS")
       dicMySql["mSql3"] = ("""SELECT z_asgard_admin.asgard_sortie_gestion_schema('mon_schema')""","EXECUTE FONCTION ASGARD")
       dicMySql["mSql4"] = ("""SELECT * FROM pg_available_extensions""","CONTENU SUR LES EXTENSIONS DU SERVEUR POSTGRESQL")
   
       for i in range(1, 5) :
           r = mBaseAsgard.executeSql(mBaseAsgard.mConnectEnCoursPointeur, dicMySql["mSql" + str(i)][0])
           if i == 2:
              #enlever le deuxième argument
              schemas = [row[0] for row in r]
              print( dicMySql["mSql" + str(i)][1])
              print(schemas)
           else :
              print(dicMySql["mSql" + str(i)][1])
              for rowR in r :
                  print(str(rowR))
    mBaseAsgard.deconnectBase()
    return

asgardPostgresql()
