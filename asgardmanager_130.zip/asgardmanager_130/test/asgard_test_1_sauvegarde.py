from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import (QAction, QMenu , QApplication, QMessageBox, QFileDialog, QTextEdit, QMainWindow) 
 
from PyQt5.QtCore import *
from PyQt5.QtGui import QIcon
from PyQt5.QtGui import *

from qgis.core import QgsProject,QgsMapLayer, QgsVectorLayerCache, QgsFeatureRequest, QgsSettings
from qgis.utils import iface
import psycopg2

def listBase():
    mSettings = QSettings()
    mSettings.beginGroup("/PostgreSQL/connections")
    mListeBase = mSettings.childGroups()
    return mListeBase
    
class BASEPOSTGRES :
    def __init__(self, nameBase):
        self.nameBase = nameBase
        mSettings = QSettings()
        mSettings.beginGroup("/PostgreSQL/connections/{}".format(self.nameBase))
        if not mSettings.contains("database") :
           QMessageBox.critical(self, "Error", "There is no defined database connection")
           mListConnectBase = []
        else :
           settingsList = ["service", "host", "port", "database", "username", "password"]
           self.service, self.host, self.port, self.database, self.username, self.password = map(lambda x: mSettings.value(x, "", type=str), settingsList)
           mListConnectBase = [self.service, self.host, self.port, self.database, self.username, self.password ]
        mSettings.endGroup()
        
        self.nameBasemListConnectBase = mListConnectBase
    #----------------------
    def connectBase(self) :
        print("affiche service : " + str(self.service))
        mSettings = QSettings()
        mSettings.beginGroup("/PostgreSQL/connections/{}".format(self))
        uri = QgsDataSourceUri()
        useEstimatedMetadata = mSettings.value("estimatedMetadata", False, type=bool)
        uri.setUseEstimatedMetadata(useEstimatedMetadata)
        self.sslmode = uri.decodeSslMode(mSettings.value("sslmode"))
        print("SSLMODE : " + str(self.sslmode) )

        try :
           if self.service:
              print("Yes Service")
              mConfigConnection = "service{0} dbname={1} user={2} password={3} sslmode={4}".format(self.service, self.database, self.username, self.password, self.sslmode)
              mConfigConnection = "service{0} dbname={1} user={2} password={3} sslmode={4}".format(self.service, self.database, self.username, self.password)
              mConnectEnCours = psycopg2.connect(mConfigConnection)
           else:
              print("No Service")
              mConfigConnection = "host={0} port={1} dbname={2} user={3} password={4} sslmode={5}".format(self.host, self.port, self.database, self.username, self.password, self.sslmode)
              mConfigConnection = "host={0} port={1} dbname={2} user={3} password={4} ".format(self.host, self.port, self.database, self.username, self.password)
              mConnectEnCours = psycopg2.connect(mConfigConnection)
           self.mConnectEnCours = mConnectEnCours.cursor()
           return True, self.mConnectEnCours
        except :
           QMessageBox.warning(None,"ASGARD : Connection","La connection est impossible")
           return False, None
        mSettings.endGroup()
    #----------------------
    def executeSql(self,pointeurBase, mSql) :
        pointeurBase.execute(mSql)
        result = pointeurBase.fetchall()
        return result
        
def update_schema_list(uri):
    uri.connection.commit()
    cur = uri.connection.cursor()
    cur.execute("""
           select nspname
           from pg_namespace
           where nspname not ilike 'pg_%'
           and nspname not in ('pg_catalog', 'information_schema')
           """)
    schemas = [row[0] for row in cur.fetchall()]
    return schemas
    
#==================================================
def openShowTableAttributeSelected(attributBar):
    mQSettings = QSettings()
    oldValueOpenAttribut = mQSettings.value("qgis/attributeTableBehavior")
    mQSettings.setValue("qgis/attributeTableBehavior","ShowSelected")
    myValueButtonAttribut = returnValueOpenShowTableAttribute(attributBar)
    attributBar.children()[myValueButtonAttribut].actions()[0].trigger()
    mQSettings.setValue("qgis/attributeTableBehavior",oldValueOpenAttribut)         

#==================================================
def returnValueOpenShowTableAttribute(attributBar):
   valueReturnOpenShowTableAttribute = 5 #Value Default
   ii = 0  
   chsBar  = attributBar.children()
   
   for ii in range(len(chsBar)) :
       try :
          if chsBar[ii].actions()[0].objectName() == "mActionOpenTable" :
             valueReturnOpenShowTableAttribute = ii
             break
       except :
          pass
          
       ii += 1
   return valueReturnOpenShowTableAttribute
   
#==================================================

def field_readonly(layer, fieldname, option = True):
    fields = layer.fields()
    field_idx = fields.indexOf(fieldname)
    if field_idx >= 0:
        form_config = layer.editFormConfig()
        form_config.setReadOnly(field_idx, option)
        layer.setEditFormConfig(form_config)
"""
project = QgsProject.instance()
layers = project.mapLayers() 
#---------------
for layer in layers.values():
    a = field_readonly(layer,'type')
    print(str(a))
"""    
#==================================================
    
mIface = iface
#mIfaceActive = mIface.activeLayer()

mySource = "D:\\Divers_test\\camino\\titres-m-ar-dmc.geojson"
fluxTitre = "Didier"
fluxProvider = "ogr"
vlayer = QgsVectorLayer(mySource, fluxTitre, fluxProvider)
mIfaceActive = vlayer
iface.setActiveLayer(mIfaceActive)

expression  = "nature = 'Station de traitement'"
expression  = "srid > 2900 and srid < 3000"
expression  = "niv1 = 'agriculture' or niv1 = 'air_climat'"

request = QgsFeatureRequest().setFilterExpression(expression)
print(mIfaceActive.name())
mIfaceFilter = mIfaceActive.getFeatures(request)
mIfaceActive.select([k.id() for k in mIfaceFilter])
attributBar = mIface.attributesToolBar()
#iface.showAttributeTable(mIfaceActive)

#openShowTableAttributeSelected(attributBar)

#retour liste base pp
print(listBase()) 
for i in range(len(listBase())):
    lNameBase = listBase()[i]
    print(lNameBase)
    print(BASEPOSTGRES(lNameBase)) 

mBaseAsgard = BASEPOSTGRES(listBase()[0])    
connectBaseAsgard= mBaseAsgard.connectBase()
print(connectBaseAsgard)
if connectBaseAsgard[0] :
   mSql1 = """
               SELECT "gestion_schema_usr".* 
               FROM "z_asgard"."gestion_schema_usr"
           """
   mSql2 = """
           select nspname
           from pg_namespace
           where nspname not ilike 'pg_%'
           and nspname not in ('pg_catalog', 'information_schema')
           """

   r = mBaseAsgard.executeSql(mBaseAsgard.mConnectEnCours, mSql2)
   print(r)
   #enlever le deuxième argument
   schemas = [row[0] for row in r]
   print(schemas)