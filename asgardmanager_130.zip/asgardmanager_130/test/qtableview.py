import sys
from PyQt5 import QtCore, QtGui, QtWidgets 
from PyQt5.Qt import *
from PyQt5.QtGui import QIcon
import glob
import os.path

	
    
def viewInfos(mRow):
    print("j'ai clicqué"  +str(mRow()))
    
    return
    
def loadFile():
    print("j'ai clicqué"  +str(mRow()))
    
    return 
       
def returnIcon( iconAdress) :
    iconSource = iconAdress
    iconSource = iconSource.replace("\\","/")
    icon = QtGui.QIcon()
    icon.addPixmap(QtGui.QPixmap(iconSource), QtGui.QIcon.Normal, QtGui.QIcon.Off)
    return icon 
"""        
# Our main window will be a QListView
list = QListView()
list.setWindowTitle('Example List')
list.setMinimumSize(600, 400)
list.setGeometry(50, 50, 100, 100)
list.itemClicked.connect(loadFile)
list.currentItemChanged.connect(loadFile)

menuIcon = "C:\\Users\\didier.leclerc\\AppData\\Roaming\\QGIS\\QGIS3\\profiles\\default\\python\\plugins\\asgard\\icons\\asgard.ico"
pathIcon = "C:\\Users\\didier.leclerc\\AppData\\Roaming\\QGIS\\QGIS3\\profiles\\default\\python\\plugins\\asgard\\icons"

mValues = []
for i in range(10):
     mValue = 'Item %s' % (i + 1)
     print(mValue)
     item = QStandardItem(returnIcon(menuIcon), str(mValue))
     item.setIcon(returnIcon(menuIcon))	
     mValues.append(mValue)

print(mValues)
list.addItems(mValues)
    
# Create an empty model for the list's data
model = QStandardItemModel(list)
 
# Add some textual items
foods = [
    'Cookie dough', # Must be store-bought
    'Hummus', # Must be homemade
    'Spaghetti', # Must be saucy
    'Dal makhani', # Must be spicy
    'Chocolate whipped cream' # Must be plentiful
]
 
for food in foods:
    # create an item with a caption
    item = QStandardItem(food)
 
    # add a checkbox to it
    item.setCheckable(True)
 
    # Add the item to the model
    model.appendRow(item)
 
# Apply the model to the list view
#list.setModel(model)
list.currentItemChanged.connect(viewInfos)
mRow = list.currentRow()

list.itemClicked.connect(lambda : viewInfos(mRow)) 
# Show the window and run the app
#list.show()
"""
class mTreeView(QTreeWidget):
    def __init__(self, *args):
        QTreeWidget.__init__(self, *args)
        #--------
        self.setColumnCount(1)
        self.insertTopLevelItems( 0, [ QTreeWidgetItem(None, [ "Droits" ] ) ] )
        menuIcon = "C:\\Users\\didier.leclerc\\AppData\\Roaming\\QGIS\\QGIS3\\profiles\\default\\python\\plugins\\asgard\\icons\\schema.png"

        root = self.topLevelItem( 0 )
        root.setIcon(0, returnIcon(menuIcon))


        for i in range(10):
            menuIcon = "C:\\Users\\didier.leclerc\\AppData\\Roaming\\QGIS\\QGIS3\\profiles\\default\\python\\plugins\\asgard\\icons\\table.png"
            node = QTreeWidgetItem(None, [ "Droits : Item" + str(i) ] )
            node.setIcon(0, returnIcon(menuIcon))
            root.addChild( node )
        
        self.itemDoubleClicked.connect( self.processItem )
        #--------

        #self.setColumnCount(1)
        self.insertTopLevelItems( 0, [ QTreeWidgetItem(None, [ "Schémas" ] ) ] )
        menuIcon = "C:\\Users\\didier.leclerc\\AppData\\Roaming\\QGIS\\QGIS3\\profiles\\default\\python\\plugins\\asgard\\icons\\schema.png"

        root = self.topLevelItem( 0 )
        root.setIcon(0, returnIcon(menuIcon))


        for i in range(10):
            menuIcon = "C:\\Users\\didier.leclerc\\AppData\\Roaming\\QGIS\\QGIS3\\profiles\\default\\python\\plugins\\asgard\\icons\\table.png"
            node = QTreeWidgetItem(None, [ "Schémas : Item" + str(i) ] )
            node.setIcon(0, returnIcon(menuIcon))
            root.addChild( node )
        
        self.itemDoubleClicked.connect( self.processItem )
        
        
    def processItem(self, item, column):
        print( ">>> " + str(item) + " - " + item.data(column, Qt.DisplayRole) )

m = mTreeView()
m.show()

def exemple1() :
    # The app doesn't receive sys.argv, because we're using
    # sys.argv[1] to receive the image directory
    app = QApplication([])
 
    # Create a window, set its size, and give it a layout
    win = QWidget()
    win.setWindowTitle('Image List')
    win.setMinimumSize(600, 400)
    layout = QVBoxLayout()
    win.setLayout(layout)
 
    # Create one of our ImageFileList objects using the image
    # directory passed in from the command line
    lst = ImageFileList(pathIcon, win)
 
    layout.addWidget(lst)
 
    entry = QLineEdit(win)
 
    layout.addWidget(entry)
 
    def on_item_changed(curr, prev):
        entry.setText(curr.text())
 
    lst.currentItemChanged.connect(on_item_changed)
 
    win.show()
    print("bip")
    return
#exemple1() 