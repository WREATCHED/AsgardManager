
regex = r"Alors"
test_str = "Alors on Alors danse !!!"
matches = re.finditer(regex, test_str)
print(enumerate(matches))
for matchNum, match in enumerate(matches):
    print(matchNum)
    print(match)
    matchNum = matchNum + 1
        
    print ("Match {matchNum} was found at {start}-{end}: {match}".format(matchNum = matchNum, start = match.start(), end = match.end(), match = match.group()))
        
    for groupNum in range(0, len(match.groups())):
        groupNum = groupNum + 1
            
        print ("Group {groupNum} found at {start}-{end}: {group}".format(groupNum = groupNum, start = match.start(groupNum), end = match.end(groupNum), group = match.group(groupNum)))
        
#       Match 1 was found at 0-5: Alors        