import sys
from PyQt5.QtWidgets import (QTreeWidget)
from PyQt5.QtCore import *

#============================
class MYEXPLO() :
   def __init__(self):
       #-
       self.iface = qgis.utils.iface
       self.myExplo = iface.mainWindow().findChild(QDockWidget,'Browser')
       self.myExplo.setWindowTitle("Dock Didier")
       #-
       self.myExploTreeview = self.myExplo.findChild(QTreeView)
       #-
       #Connexion
       self.myExploTreeview.clicked.connect(self.traitement)
       return
       
   #---------------
   def traitement(self, objIndex):
       cChaineConnexion = objIndex.data(Qt.UserRole)
       try :
         cChaineConnexion = cChaineConnexion.split("/")[1]
       except : 
         return
         
       try :
         nameBasemListConnectBase,mConfigConnection, uri = self.returnconnexion(cChaineConnexion)
       except : 
         return
       mNameGeom, mMesComment = self.returnNameGeom(uri, objIndex.data())
       print( "\n>COUCOU\n\n mes commentaires :\n\n{}\n\n".format(str(mMesComment) ))
       self.loadLayer(uri, objIndex.parent().data(), objIndex.data(), mNameGeom, "postgres")
       #-
       return

   #---------------
   def returnNameGeom(self, uri, layer):
       mcConnexion = QgsProviderRegistry.instance().providerMetadata('postgres').createConnection(uri.uri(),{})

       for idTable in mcConnexion.tables() :
           if layer == idTable.tableName() :
              print(dir(idTable.tableName))
              break
       return idTable.geometryColumn(), idTable.comment()

   #---------------
   def loadLayer(self, uri, schema, layer, mNameGeom, provider):
       uri.setDataSource(schema, layer, mNameGeom, "")
       mLayer = QgsVectorLayer(uri.uri(), layer, provider)
       print( "\n>>> htmlMetaData : {}".format(str(mLayer.htmlMetadata()) ))
       if not mLayer: return
       QgsProject.instance().addMapLayer(mLayer)
       return

   #---------------
   def returnconnexion(self, mNameConnexion):
       mSettings = QgsSettings()
       print(mNameConnexion)
       self.mConnectionSettingsKey = "/PostgreSQL/connections/{}".format(mNameConnexion)
       mSettings.beginGroup(self.mConnectionSettingsKey)
       if not mSettings.contains("database") :
          QMessageBox.critical(None, "Error", "There is no defined database connection")
          mListConnectBase = []
          return
       else :
          uri = QgsDataSourceUri()
          settingsList = ["service", "host", "port", "database", "username", "password"]
          self.service, self.host, self.port, self.database, self.username, self.password = map(lambda x: mSettings.value(x, "", type=str), settingsList)
          mListConnectBase = [self.service, self.host, self.port, self.database, self.username, self.password ]
          useEstimatedMetadata = mSettings.value("estimatedMetadata", False, type=bool)
          self.sslmode = mSettings.enumValue("sslmode", uri.SslPrefer)
       mSettings.endGroup()

       if self.service:
          mConfigConnection = "service{0} dbname={1} user={2} password='{3}' sslmode={4}".format(self.service, self.database, self.username, self.password, self.sslmode)
          uri.setConnection(self.service, self.database, self.username, self.password, self.sslmode)
       else:
          mConfigConnection = "host={0} port={1} dbname={2} user={3} password='{4}' sslmode={5}".format(self.host, self.port, self.database, self.username, self.password, self.sslmode)
          uri.setConnection(self.host, self.port, self.database, self.username, self.password, self.sslmode)

       uri.setUseEstimatedMetadata(useEstimatedMetadata)
       self.nameBasemListConnectBase, self.mConfigConnection, self.uri = mListConnectBase, mConfigConnection, uri
       
       return self.nameBasemListConnectBase, self.mConfigConnection, self.uri

   #---------------
   def controlNameDock(self):
       mW = self.iface.mainWindow()
       mwChildren = mW.children() 
       #-
       for elem in mwChildren :
         if 'brow' in str(elem.objectName().lower()) :
            print("mW.children %s" %(str(elem.objectName())))
       #-
       explo = iface.mainWindow().findChild(QDockWidget,'Browser')
       print("explo %s" %(str(explo)))
       explo.hide()
       explo.show()
       return
             

explo = MYEXPLO()
# Test et affiche l'objet QDockWidget
explo.controlNameDock()
   
