SELECT
        nom_schema,
        CASE WHEN 'table' = 'function'
            THEN quote_ident(relname::text) || substring(pg_class.oid::regprocedure::text, '[(][^()]*[)]$')
            ELSE relname::text END AS objname,
        'table' AS objtype
        FROM z_asgard.gestion_schema_etr
            LEFT JOIN pg_catalog.pg_class ON oid_schema = relnamespace
            LEFT JOIN pg_catalog.pg_depend ON objid = pg_class.oid
        WHERE relkind = ANY (ARRAY['r', 'p']) AND NOT deptype = 'i'
         UNION SELECT
        nom_schema,
        CASE WHEN 'view' = 'function'
            THEN quote_ident(relname::text) || substring(pg_class.oid::regprocedure::text, '[(][^()]*[)]$')
            ELSE relname::text END AS objname,
        'view' AS objtype
        FROM z_asgard.gestion_schema_etr
            LEFT JOIN pg_catalog.pg_class ON oid_schema = relnamespace
            LEFT JOIN pg_catalog.pg_depend ON objid = pg_class.oid
        WHERE relkind = 'v' AND NOT deptype = 'i'
         UNION SELECT
        nom_schema,
        CASE WHEN 'materialized view' = 'function'
            THEN quote_ident(relname::text) || substring(pg_class.oid::regprocedure::text, '[(][^()]*[)]$')
            ELSE relname::text END AS objname,
        'materialized view' AS objtype
        FROM z_asgard.gestion_schema_etr
            LEFT JOIN pg_catalog.pg_class ON oid_schema = relnamespace
            LEFT JOIN pg_catalog.pg_depend ON objid = pg_class.oid
        WHERE relkind = 'm' AND NOT deptype = 'i'
         UNION SELECT
        nom_schema,
        CASE WHEN 'foreign table' = 'function'
            THEN quote_ident(relname::text) || substring(pg_class.oid::regprocedure::text, '[(][^()]*[)]$')
            ELSE relname::text END AS objname,
        'foreign table' AS objtype
        FROM z_asgard.gestion_schema_etr
            LEFT JOIN pg_catalog.pg_class ON oid_schema = relnamespace
            LEFT JOIN pg_catalog.pg_depend ON objid = pg_class.oid
        WHERE relkind = 'f' AND NOT deptype = 'i'
         UNION SELECT
        nom_schema,
        CASE WHEN 'function' = 'function'
            THEN quote_ident(proname::text) || substring(pg_proc.oid::regprocedure::text, '[(][^()]*[)]$')
            ELSE proname::text END AS objname,
        'function' AS objtype
        FROM z_asgard.gestion_schema_etr
            LEFT JOIN pg_catalog.pg_proc ON oid_schema = pronamespace
            LEFT JOIN pg_catalog.pg_depend ON objid = pg_proc.oid
        WHERE true AND NOT deptype = 'i'
         ORDER BY nom_schema, objtype, objname
