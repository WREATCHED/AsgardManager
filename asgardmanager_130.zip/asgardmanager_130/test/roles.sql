    WITH
    a_edi AS (SELECT coalesce(oid_editeur, 0) AS oid_editeur FROM z_asgard.asgardmanager_metadata WHERE nom_schema = 'z_asgard'),
    a_pro AS (SELECT nspowner FROM pg_catalog.pg_namespace WHERE quote_ident(nspname)::regnamespace::text = 'z_asgard'),
    
    roles_1 AS (
        SELECT
            -- informations g�n�riques
            roles.rolname, roles.rolsuper, roles.rolinherit,
            roles.rolcreaterole, roles.rolcreatedb, roles.rolcanlogin, roles.rolreplication,
            roles.rolconnlimit, roles.rolpassword, roles.rolvaliduntil, roles.rolbypassrls,
            roles.rolconfig, roles.oid,
            
            -- commentaire sur le r�le
            shobj_description(roles.oid, 'pg_authid') AS description,
            
            -- gestion des sch�mas
            roles.rolsuper OR bool_or(pg_database.datname = current_database()) AS db_create
            
            FROM pg_catalog.pg_roles AS roles
                LEFT JOIN pg_catalog.pg_database ON array_to_string(datacl, ',') ~ ('^(.*[,])*' || z_asgard.asgard_role_trans_acl(roles.oid::regrole) || '[=][cT]*C[cT]*[/]')
            WHERE NOT rolname ~ ANY (ARRAY['^pg_', '^postgres$'])
            GROUP BY roles.rolname, roles.rolsuper, roles.rolinherit,
                roles.rolcreaterole, roles.rolcreatedb, roles.rolcanlogin, roles.rolreplication,
                roles.rolconnlimit, roles.rolpassword, roles.rolvaliduntil, roles.rolbypassrls,
                roles.rolconfig, roles.oid
    ),
    roles_2 AS (
        SELECT
            roles_1.*,
            -- membres du r�les
            array_agg(DISTINCT membres.member ORDER BY membres.member) AS membres
            FROM roles_1 LEFT JOIN pg_catalog.pg_auth_members AS membres ON roles_1.oid = membres.roleid
            GROUP BY roles_1.rolname, roles_1.rolsuper, roles_1.rolinherit,
                roles_1.rolcreaterole, roles_1.rolcreatedb, roles_1.rolcanlogin, roles_1.rolreplication,
                roles_1.rolconnlimit, roles_1.rolpassword, roles_1.rolvaliduntil, roles_1.rolbypassrls,
                roles_1.rolconfig, roles_1.oid, roles_1.description, db_create
    ),
    roles_3 AS (
        SELECT
            roles_2.*,
            -- gestion des sch�mas (suite)
            coalesce(bool_or(parents.roleid = a_edi.oid_editeur), false) -- membre direct de l'�diteur de z_asgard
                OR roles_2.oid = a_edi.oid_editeur -- ou l'�diteur lui-m�me
                OR roles_2.rolname = 'g_admin' -- ou g_admin
                OR roles_2.rolsuper -- ou un superutilisateur
                AS asgard_edi,
            
            -- r�les dont le r�le est membre
            array_agg(DISTINCT parents.roleid ORDER BY parents.roleid) AS parents
            FROM a_pro, a_edi, roles_2 LEFT JOIN pg_catalog.pg_auth_members AS parents ON roles_2.oid = parents.member
            GROUP BY roles_2.rolname, roles_2.rolsuper, roles_2.rolinherit,
                roles_2.rolcreaterole, roles_2.rolcreatedb, roles_2.rolcanlogin, roles_2.rolreplication,
                roles_2.rolconnlimit, roles_2.rolpassword, roles_2.rolvaliduntil, roles_2.rolbypassrls,
                roles_2.rolconfig, roles_2.oid, roles_2.description, db_create, membres, a_edi.oid_editeur
    ),
    roles_4 AS (
        SELECT
            roles_3.*,
            -- droits du r�le sur les sch�mas r�f�renc�s par ASGARD
            array_agg(ARRAY[nom_schema, (asgardmanager_metadata.oid_lecteur = roles_3.oid)::text] ORDER BY asgardmanager_metadata.nom_schema)
                FILTER (WHERE pg_has_role(roles_3.oid, asgardmanager_metadata.oid_lecteur, 'USAGE')) AS schema_lec,
            array_agg(ARRAY[nom_schema, (asgardmanager_metadata.oid_editeur = roles_3.oid)::text] ORDER BY asgardmanager_metadata.nom_schema)
                FILTER (WHERE pg_has_role(roles_3.oid, asgardmanager_metadata.oid_editeur, 'USAGE')) AS schema_edi,
            array_agg(ARRAY[nom_schema, (asgardmanager_metadata.oid_producteur = roles_3.oid)::text] ORDER BY asgardmanager_metadata.nom_schema)
                FILTER (WHERE pg_has_role(roles_3.oid, asgardmanager_metadata.oid_producteur, 'USAGE')) AS schema_pro
            FROM roles_3, z_asgard.asgardmanager_metadata
            GROUP BY roles_3.rolname, roles_3.rolsuper, roles_3.rolinherit,
                roles_3.rolcreaterole, roles_3.rolcreatedb, roles_3.rolcanlogin, roles_3.rolreplication,
                roles_3.rolconnlimit, roles_3.rolpassword, roles_3.rolvaliduntil, roles_3.rolbypassrls,
                roles_3.rolconfig, roles_3.oid, roles_3.description, roles_3.db_create, roles_3.asgard_edi,
                roles_3.membres, roles_3.parents
    )
    SELECT
    roles_4.rolname, roles_4.rolsuper, roles_4.rolinherit,
    roles_4.rolcreaterole, roles_4.rolcreatedb, roles_4.rolcanlogin, roles_4.rolreplication,
    roles_4.rolconnlimit, roles_4.rolpassword, roles_4.rolvaliduntil, roles_4.rolbypassrls,
    roles_4.rolconfig, roles_4.oid, roles_4.description, membres, parents,
    schema_lec, schema_edi, schema_pro, db_create, asgard_edi,
    
    -- bases contenant des objets d�pendants du r�le
    array_agg(DISTINCT pg_database.datname::text ORDER BY pg_database.datname::text) FILTER (WHERE pg_database.datname IS NOT NULL) AS db_dependances
    FROM roles_4
        LEFT JOIN pg_catalog.pg_shdepend
            ON roles_4.oid = pg_shdepend.refobjid AND pg_shdepend.refclassid = 'pg_authid'::regclass
        LEFT JOIN pg_catalog.pg_database
            ON pg_shdepend.dbid = pg_database.oid
                OR pg_shdepend.classid = 'pg_database'::regclass AND pg_shdepend.objid = pg_database.oid
    GROUP BY roles_4.rolname, roles_4.rolsuper, roles_4.rolinherit,
        roles_4.rolcreaterole, roles_4.rolcreatedb, roles_4.rolcanlogin, roles_4.rolreplication,
        roles_4.rolconnlimit, roles_4.rolpassword, roles_4.rolvaliduntil, roles_4.rolbypassrls,
        roles_4.rolconfig, roles_4.oid, roles_4.description, db_create, asgard_edi, membres, parents,
        schema_lec, schema_edi, schema_pro
    ORDER BY roles_4.rolname
    ;