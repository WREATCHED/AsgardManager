from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import (QAction, QMenu , QApplication, QMessageBox, QFileDialog, QTextEdit, QMainWindow) 
 
from PyQt5.QtCore import *
from PyQt5.QtGui import QIcon
from PyQt5.QtGui import *

from qgis.utils import iface
import json
import requests



def load_file(mFile):
    response = requests.get("https://jsonplaceholder.typicode.com/todos")
    listTodos = json.loads(response.text)

    with open(mFile, "w",encoding="utf-8") as zFilejson :
       for mDict in listTodos :
          for key, value in mDict.items() :
             mVal = "clé :  %s -- Valeur : %s\n" %(str(key),str(value))
             zFilejson.write(mVal)

myPathFile = "C:\\Users\\didier.leclerc\\AppData\\Roaming\\QGIS\\QGIS3\\profiles\\default\\python\\plugins\\asgardmanager\\json\\testjson.txt" 
load_file(myPathFile)
