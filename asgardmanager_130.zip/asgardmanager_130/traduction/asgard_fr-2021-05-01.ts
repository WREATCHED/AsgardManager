<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0">
<context>
    <name>about</name>
    <message>
        <location filename="../about.py" line="125"/>
        <source>ASGARD Manager</source>
        <translation type="unfinished">ASGARD Manager</translation>
    </message>
    <message>
        <location filename="../about.py" line="111"/>
        <source>MTE / MCTRCT / Mer</source>
        <translation type="unfinished">MTE / MCTRCT / Mer</translation>
    </message>
    <message>
        <location filename="../about.py" line="114"/>
        <source>digital service</source>
        <translation type="unfinished">Service du numérique</translation>
    </message>
    <message>
        <location filename="../about.py" line="117"/>
        <source>digital service SG/SNUM/UNI/DRC</source>
        <translation type="unfinished">Service du numérique SG/SNUM/UNI/DRC</translation>
    </message>
    <message>
        <location filename="../about.py" line="124"/>
        <source>ASGARD Manager - Automatic and Simplified GrAnting for Rights in Databases</source>
        <translation type="unfinished">ASGARD Manager - Gestion automatique et simplifiée des droits dans les bases de données</translation>
    </message>
    <message>
        <location filename="../about.py" line="127"/>
        <source>OK</source>
        <translation type="unfinished">OK</translation>
    </message>
    <message>
        <location filename="../about.py" line="97"/>
        <source>A tool dedicated to ADL and / or ADL delegates, Asgard Manager was developed to allow IG departments of the ministry, which do not have strong skills under the PostGreSQL environment, to exploit the features of the Asgard extension.</source>
        <translation type="unfinished">Outil dédié aux ADL et/ou ADL délégués, Asgard Manager a été développé pour permettre aux services IG du ministère, qui ne disposent pas de fortes compétences sous l’environnement PostGreSQL d’ exploiter les fonctionnalités de l’extension Asgard.</translation>
    </message>
    <message>
        <location filename="../about.py" line="99"/>
        <source>Asgard Manager encapsulates the instructions or functionality of the Asgard extension and PostGreSQL SQL language</source>
        <translation type="unfinished">Asgard Manager encapsule les instructions ou fonctionnalités de l’extension Asgard et du langage SQL de PostGreSQL.</translation>
    </message>
    <message>
        <location filename="../about.py" line="102"/>
        <source>Representation of functional blocks, diagrams, objects, roles of groups and connections with dedicated iconography and graphic statistical analyzes.</source>
        <translation type="unfinished">Représentation des blocs fonctionnels, des schémas, des objets, des rôles de groupes et de connexions avec une iconographie dédiée et des analyses statistiques graphiques.</translation>
    </message>
    <message>
        <location filename="../about.py" line="108"/>
        <source>Designer/Developer Didier LECLERC</source>
        <translation type="unfinished">Concepteur/Développeur Didier LECLERC</translation>
    </message>
    <message>
        <location filename="../about.py" line="109"/>
        <source>functional analysis Leslie LEMAIRE</source>
        <translation type="unfinished">Analyse fonctionnelle Leslie LEMAIRE</translation>
    </message>
    <message>
        <location filename="../about.py" line="120"/>
        <source>Development in 2020/2021</source>
        <translation type="unfinished">Développement en 2020/2021</translation>
    </message>
</context>
<context>
    <name>asgard_general_ui</name>
    <message>
        <location filename="../asgard_general_ui.py" line="405"/>
        <source>ASGARD Manager - Automatic and Simplified GrAnting for Rights in Databases</source>
        <translation type="unfinished">ASGARD Manager - Gestion automatique et simplifiée des droits dans les bases de données</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="406"/>
        <source>Help</source>
        <translation type="unfinished">Aide</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="407"/>
        <source>Close</source>
        <translation type="unfinished">Quitter</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="576"/>
        <source>Your database is not ASGARD compatible</source>
        <translation type="unfinished">Votre base de données n&apos;est pas compatible ASGARD, vérifiez que vous avez saisi votre mot de passe dans la connexion QGIS</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="744"/>
        <source>Good you have a create schema !!</source>
        <translation type="unfinished">Schéma créé !!</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="919"/>
        <source>Information !!!</source>
        <translation type="unfinished">Information !!!</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="747"/>
        <source>Good you have a update schema !!</source>
        <translation type="unfinished">Schéma mis à jour !!</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="786"/>
        <source>the roles of producers, editors and readers cannot be equal</source>
        <translation type="unfinished">les rôles des producteurs, éditeurs et lecteurs ne peuvent pas être égaux</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="896"/>
        <source>ASGARD MANAGER : Warning</source>
        <translation type="unfinished">ASGARD MANAGER : Attention</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="790"/>
        <source>Schema cannot be empty</source>
        <translation type="unfinished">Le nom du schéma ne peut être vide</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="856"/>
        <source>the diagram already exists in actif in the trash</source>
        <translation type="unfinished">Le schéma existe déjà dans les actifs de la corbeille</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="858"/>
        <source>the diagram already exists in actif</source>
        <translation type="unfinished">Le schéma existe déjà dans les actifs</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="866"/>
        <source>the diagram already exists in non-active in the trash</source>
        <translation type="unfinished">Le schéma existe déjà dans les non-actifs de la corbeille</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="868"/>
        <source>the diagram already exists in non-active</source>
        <translation type="unfinished">Le schéma existe déjà dans les non-actifs</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="876"/>
        <source>the diagram already exists in the trash</source>
        <translation type="unfinished">Le schéma existe déjà dans la corbeille</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="878"/>
        <source>the diagram already exists</source>
        <translation type="unfinished">Le schéma existe déjà</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="408"/>
        <source>List of PostgreSQL connections : </source>
        <translation type="unfinished">Liste des connexions PostgreSQL</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="891"/>
        <source>No value changed</source>
        <translation type="unfinished">Aucune valeur modifiée</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="574"/>
        <source>ASGARD MANAGER : error handler </source>
        <translation type="unfinished">ASGARD MANAGER : gestionnaire d&apos;erreurs</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="208"/>
        <source>  diagrams  </source>
        <translation type="unfinished">  Schémas  </translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="213"/>
        <source>   Roles   </source>
        <translation type="unfinished">   Rôles   </translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../bibli_ihm_asgard.py" line="671"/>
        <source>Good you have a create rôle !!</source>
        <translation type="unfinished">Rôle créé !!</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="86"/>
        <source>Settings</source>
        <translation type="unfinished">Gestion de la base</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="218"/>
        <source>   statistics   </source>
        <translation type="unfinished">   Statistiques   </translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="409"/>
        <source>Choice of chart : </source>
        <translation type="unfinished">Choix du graphique : </translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="410"/>
        <source>Apply</source>
        <translation type="unfinished">Appliquer</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="411"/>
        <source>Block colors</source>
        <translation type="unfinished">Couleurs des blocs</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="512"/>
        <source>Initialization failed. The PostgreSQL ASGARD extension is not installed on the target database for this connection.</source>
        <translation type="unfinished">Échec de l&apos;initialisation. L&apos;extension PostgreSQL ASGARD n&apos;est pas installée sur la base cible de cette connexion.</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="551"/>
        <source>Permission denied. To use the AsgardManager plugin, you must connect to the PostgreSQL server with a role that is a member of the g_admin group.)</source>
        <translation type="unfinished">Permission refusée. Pour utiliser le plugin AsgardManager, vous devez vous connecter au serveur PostgreSQL avec un rôle membre du groupe g_admin.</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="229"/>
        <source>   diagnostics   </source>
        <translation type="unfinished">   Diagnostics   </translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="440"/>
        <source>Diagnostic: Print preview</source>
        <translation type="unfinished">Diagnostic : Aperçu avant impression</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="444"/>
        <source>Diagnostic: Delele result</source>
        <translation type="unfinished">Diagnostic : Effacer les résultats</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="404"/>
        <source>Filter : </source>
        <translation type="unfinished">Filtre : </translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="958"/>
        <source>Enter text to filter ...</source>
        <translation type="unfinished">Tapez un texte pour filtrer ...</translation>
    </message>
</context>
<context>
    <name>asgard_main</name>
    <message>
        <location filename="../asgard.py" line="45"/>
        <source>Asgard Manager (Automatic and Simplified GrAnting for Rights in Databases)</source>
        <translation type="unfinished">Asgard Manager (Gestion automatique et simplifiée des droits dans les bases de données)</translation>
    </message>
    <message>
        <location filename="../asgard.py" line="50"/>
        <source>About ...</source>
        <translation type="unfinished">A propos ...</translation>
    </message>
    <message>
        <location filename="../asgard.py" line="69"/>
        <source>My tool bar ASGARD MANAGER</source>
        <translation type="unfinished">Barre d&apos;outil ASGARD MANAGER</translation>
    </message>
    <message>
        <location filename="../asgard.py" line="41"/>
        <source>Asgard Manager</source>
        <translation type="unfinished">Asgard Manager</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="148"/>
        <source>refresh</source>
        <translation type="unfinished">Actualiser</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="92"/>
        <source>Reset all rights</source>
        <translation type="unfinished">Réinitialiser tous les droits</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="112"/>
        <source>Reference all the diagrams in the database</source>
        <translation type="unfinished">Référencer tous les schémas de la base</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="96"/>
        <source>Find all anomalies</source>
        <translation type="unfinished">Rechercher toutes les anomalies</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="116"/>
        <source>Import or repair the national nomenclature</source>
        <translation type="unfinished">Importer ou réparer la nomenclature nationale</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="122"/>
        <source>Install ASGARD on the base</source>
        <translation type="unfinished">Installer l&apos;extension ASGARD sur la base</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="126"/>
        <source>Update the ASGARD extension</source>
        <translation type="unfinished">Mettre à jour l&apos;extension ASGARD</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="130"/>
        <source>Uninstall the ASGARD extension</source>
        <translation type="unfinished">Désinstaller l&apos;extension ASGARD</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="106"/>
        <source>Make all users members of g_consult</source>
        <translation type="unfinished">Rendre tous les utilisateurs membres de g_consult</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="100"/>
        <source>Refresh the role names in the management table </source>
        <translation type="unfinished">Rafraîchir les noms de rôles dans la table de gestion</translation>
    </message>
</context>
<context>
    <name>bibli_asgard</name>
    <message>
        <location filename="../bibli_asgard.py" line="2286"/>
        <source>Schemes outside Asgard</source>
        <translation type="unfinished">Schémas externes à Asgard</translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="2368"/>
        <source>No Active Schemas</source>
        <translation type="unfinished">Schémas non actifs</translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="2941"/>
        <source>your diagram is in the trash !!</source>
        <translation type="unfinished">Le schéma est passé dans la corbeille</translation>
    </message>
    <message>
        <location filename="../colorbloc_ui.py" line="334"/>
        <source>Information !!!</source>
        <translation type="unfinished">Information !!!</translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="2874"/>
        <source>You have just emptied your trash !!</source>
        <translation type="unfinished">La corbeille a été vidée</translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="2949"/>
        <source>You have just deferenced your diagram !!</source>
        <translation type="unfinished">Le schéma a été déreférencé !!</translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="2961"/>
        <source>You have just restored your diagram !!</source>
        <translation type="unfinished">Le schéma a été restauré !!</translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="2970"/>
        <source>You just deleted your schema !!</source>
        <translation type="unfinished">Le schéma a été effacé !!</translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="2978"/>
        <source>You have just deleted a non-active diagram !!</source>
        <translation type="unfinished">Le schéma non actif a été effacé !!</translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="2987"/>
        <source>You have just created the schema in the database (made active) !!</source>
        <translation type="unfinished">le schéma est créé dans la base de données (rendu actif)</translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="2995"/>
        <source>You have just referenced your diagram !!</source>
        <translation type="unfinished">Vous venez de référencer votre schéma et réinitialiser les droits !!</translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="1440"/>
        <source>Group Roles</source>
        <translation type="unfinished">Rôles de groupe</translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="1428"/>
        <source>Connection Roles</source>
        <translation type="unfinished">Rôles de connexion</translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="2840"/>
        <source>Confirmation</source>
        <translation type="unfinished">Confirmation</translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="2108"/>
        <source>Are you sure you want to move this diagram?</source>
        <translation type="unfinished">Etes vous sûr de vouloir déplacer votre schéma ?</translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="2135"/>
        <source>Good, you have moved your diagram</source>
        <translation type="unfinished">Schéma déplacé !!</translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="2841"/>
        <source>Are you sure you want to empty your recycle bin ?</source>
        <translation type="unfinished">Etes vous sûr de vouloir vider votre corbeille ?</translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="2920"/>
        <source>Good, you have moved your objet</source>
        <translation type="unfinished">Objet déplacé !!</translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="3280"/>
        <source>Authentication problem, check your password in particular.</source>
        <translation type="unfinished">Problème d&apos;authentification, vérifiez notamment votre mot de passe.</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="996"/>
        <source>Does not belong</source>
        <translation type="unfinished">N&apos;appartient pas</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="997"/>
        <source>Belongs</source>
        <translation type="unfinished">Appartient</translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="1802"/>
        <source>Non-member role :</source>
        <translation type="unfinished">Rôles non membres :</translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="1803"/>
        <source>Group member roles :</source>
        <translation type="unfinished">Rôles membres du groupe :</translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="1809"/>
        <source>Does not belong to :</source>
        <translation type="unfinished">N&apos;appartient pas à :</translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="1810"/>
        <source>Belongs to group :</source>
        <translation type="unfinished">Appartient aux groupes :</translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="1656"/>
        <source>Are you sure you want to delete this role ?</source>
        <translation type="unfinished">Etes vous sûr de vouloir supprimer ce rôle ?</translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="1674"/>
        <source>role deletion</source>
        <translation type="unfinished">Rôle supprimé</translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="1678"/>
        <source>Are you sure you want to revoke all rights for the role ?</source>
        <translation type="unfinished">Etes vous sûr de vouloir révoquer tous les droits du rôle ?</translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="838"/>
        <source>The role is designated reader for the schema</source>
        <translation type="unfinished">Le rôle est le LECTEUR désigné pour le schéma</translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="841"/>
        <source>Role is a member of the designated reader for the schema</source>
        <translation type="unfinished">Le rôle est membre du LECTEUR désigné pour le schéma</translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="887"/>
        <source>The role is designated editor for the schema</source>
        <translation type="unfinished">Le rôle est l&apos;EDITEUR désigné pour le schéma</translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="890"/>
        <source>Role is a member of the designated editor for the schema</source>
        <translation type="unfinished">Le rôle est membre de l&apos;EDITEUR désigné pour le schéma</translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="935"/>
        <source>The role is designated producer for the schema</source>
        <translation type="unfinished">Le rôle est le PRODUCTEUR désigné pour le schéma</translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="938"/>
        <source>Role is a member of the designated producer for the schema</source>
        <translation type="unfinished">Le rôle est membre du PRODUCTEUR désigné pour le schéma</translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="1762"/>
        <source>You do not have the right to modify &apos;g_admin_ext&apos;</source>
        <translation type="unfinished">Vous n&apos;avez pas le droit de modifier le rôle de groupe &apos;G_ADMIN_EXT&apos;</translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="3020"/>
        <source>You have just restored the standard rights of the producer, editor and reader on the diagram !!</source>
        <translation type="unfinished">Vous venez de restaurer les droits standards du producteur, de l&apos;éditeur et du lecteur sur le schéma !!</translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="598"/>
        <source>Options</source>
        <translation type="unfinished">Options</translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="747"/>
        <source>Blocs</source>
        <translation type="unfinished">Blocs</translation>
    </message>
    <message>
        <location filename="../bibli_graph_asgard.py" line="65"/>
        <source>The time for this processing takes a few minutes depending on the size of your database.</source>
        <translation type="unfinished">Le temps de ce traitement nécessite quelques minutes en fonction du volume de votre base de données.</translation>
    </message>
    <message>
        <location filename="../bibli_graph_asgard.py" line="66"/>
        <source>Are you sure you want to continue ?</source>
        <translation type="unfinished">Etes-vous sûr de vouloir continuer ?</translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="2569"/>
        <source>Refer to ...</source>
        <translation type="unfinished">Référencer vers ...</translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="3003"/>
        <source>You have just referenced your schema while retaining the rights !!</source>
        <translation type="unfinished">Vous venez de référencer votre schéma en conservant les droits !!</translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="3852"/>
        <source>An update is available for the ASGARD extension.</source>
        <translation type="unfinished">Une mise à jour est disponible pour l&apos;extension ASGARD.</translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="3853"/>
        <source>The option is available in the &quot;Database management&quot; menu.</source>
        <translation type="unfinished">Pour l&apos;installer sur la base courante : menu Gestion de la base &gt; Mettre à jour l&apos;extension ASGARD.</translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="3850"/>
        <source>Warning !!!</source>
        <translation type="unfinished">Attention !!!</translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="3038"/>
        <source>You have just restored the standard rights of the producer, editor and reader on the objet !!</source>
        <translation type="unfinished">Rétablit les droits standards du producteur, de l’éditeur et du lecteur sur l’objet.</translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="1685"/>
        <source>All rights of the role </source>
        <translation type="unfinished">Tous les droits du rôle</translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="1685"/>
        <source>on the base </source>
        <translation type="unfinished">sur la base </translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="1686"/>
        <source>database have been revoked.</source>
        <translation type="unfinished">ont été révoqués.</translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="1689"/>
        <source>This role still has rights on the following bases: </source>
        <translation type="unfinished">Ce rôle a encore des droits sur les bases suivantes : </translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="1706"/>
        <source>Transfer of rights from </source>
        <translation type="unfinished">Transfert des droits de </translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="1708"/>
        <source> to </source>
        <translation type="unfinished"> à </translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="1710"/>
        <source> successful</source>
        <translation type="unfinished"> effectué.</translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="3072"/>
        <source>you have just replicated the dataset for synchronization with the central database</source>
        <translation type="unfinished">Vous venez de répliquer le jeu de données pour la synchronisation avec la base centrale</translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="3074"/>
        <source>you have just dereplicated the dataset for synchronization with the central database</source>
        <translation type="unfinished">Vous venez de dérépliquer le jeu de données pour la synchronisation avec la base centrale</translation>
    </message>
</context>
<context>
    <name>bibli_graph_asgard</name>
    <message>
        <location filename="../bibli_graph_asgard.py" line="605"/>
        <source>Graphics: Print preview</source>
        <translation type="unfinished">Graphique: Aperçu avant impression</translation>
    </message>
    <message>
        <location filename="../bibli_graph_asgard.py" line="612"/>
        <source>Graphics: Save image</source>
        <translation type="unfinished">Graphique: Sauvegarder l&apos;image</translation>
    </message>
    <message>
        <location filename="../bibli_graph_asgard.py" line="668"/>
        <source>ASGARD MANAGER Graphics</source>
        <translation type="unfinished">ASGARD MANAGER Graphiques</translation>
    </message>
    <message>
        <location filename="../bibli_graph_asgard.py" line="702"/>
        <source>Graphiques Asgard Manager</source>
        <translation type="unfinished">Graphiques ASGARD MANAGER</translation>
    </message>
    <message>
        <location filename="../bibli_graph_asgard.py" line="703"/>
        <source>Asgard Manager Charts</source>
        <translation type="unfinished">ASGARD MANAGER Graphiques</translation>
    </message>
</context>
<context>
    <name>bibli_ihm_asgard</name>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1096"/>
        <source>Schema name : </source>
        <translation type="unfinished">Nom du schéma : </translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1097"/>
        <source>Functional bloc : </source>
        <translation type="unfinished">Bloc fonctionnel :</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1100"/>
        <source>Producteur : </source>
        <translation type="unfinished">Producteur : </translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1101"/>
        <source>Editeur : </source>
        <translation type="unfinished">Editeur : </translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1102"/>
        <source>Lecteur : </source>
        <translation type="unfinished">Lecteur : </translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1095"/>
        <source>Apply</source>
        <translation type="unfinished">Appliquer</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1098"/>
        <source>Actif : </source>
        <translation type="unfinished">Actif : </translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1099"/>
        <source>Physical creation of the diagram</source>
        <translation type="unfinished">Création physique du schéma</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1350"/>
        <source>New schema</source>
        <translation type="unfinished">Nouveau schéma</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1355"/>
        <source>Move to trash</source>
        <translation type="unfinished">Mettre à la corbeille</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1360"/>
        <source>Dereferencing</source>
        <translation type="unfinished">Déréférencer</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1365"/>
        <source>Delete</source>
        <translation type="unfinished">Effacer</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1370"/>
        <source>Create in the database (make active)</source>
        <translation type="unfinished">Créer dans la base (rendre actif)</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1375"/>
        <source>Empty the trash</source>
        <translation type="unfinished">Vider la corbeille</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1380"/>
        <source>Restore</source>
        <translation type="unfinished">Restaurer</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1385"/>
        <source>Delete from the database</source>
        <translation type="unfinished">Supprimer de la base de donnée</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1390"/>
        <source>Reference</source>
        <translation type="unfinished">Référencer et réinitialiser les droits</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1351"/>
        <source>Defines a new schema, active (created in the database) or not.</source>
        <translation type="unfinished">Définit un nouveau schéma, actif (créé dans la base) ou non.</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1356"/>
        <source>An active schema put in the trash can be permanently deleted from the database.</source>
        <translation type="unfinished">Un schéma actif mis à la corbeille pourra être définitivement supprimé de la base.</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1361"/>
        <source>Excludes the diagram from the scope of Asgard. All information entered in the form will be lost. The rights previously defined for the producer, the publisher and the reader are kept identically.</source>
        <translation type="unfinished">Exclut le schéma du champ d’application d’Asgard. Toutes les informations saisies dans le formulaire seront perdues. Les droits préalablement définis pour le producteur, l’éditeur et le lecteur sont conservés à l’identique.</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1366"/>
        <source>Permanently clears information about the inactive schema from the Asgard management table.</source>
        <translation type="unfinished">Efface définitivement de la table de gestion d’Asgard les informations relatives au schéma inactif.</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1371"/>
        <source>Create the schema in the database. The schema will now appear as &apos;active&apos;.</source>
        <translation type="unfinished">Crée le schéma dans la base. Le schéma apparaîtra désormais comme &apos;actif&apos;.</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1376"/>
        <source>Permanently remove all active schemas from the recycle bin, erase inactive schemas.</source>
        <translation type="unfinished">Supprime définitivement tous les schémas actifs de la corbeille, efface les schémas inactifs.</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1381"/>
        <source>Take the diagram out of the trash and place it back in its original block.</source>
        <translation type="unfinished">Sort le schéma de la corbeille et le replace dans son bloc d’origine.</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1386"/>
        <source>Permanently deletes the schema and its contents from the database. The schema remains referenced by Asgard as an &apos;inactive&apos; schema.</source>
        <translation type="unfinished">Supprime définitivement le schéma et son contenu de la base. Le schéma reste référencé par Asgard en tant que schéma &apos;inactif&apos;.</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1104"/>
        <source>Nomenclature : </source>
        <translation type="unfinished">Nomenclature : </translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1105"/>
        <source>Level 1 : </source>
        <translation type="unfinished">Niveau 1 : </translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1106"/>
        <source>Level 1 (standard) : </source>
        <translation type="unfinished">Niveau 1 (standard) : </translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1107"/>
        <source>Level 2 : </source>
        <translation type="unfinished">Niveau 2 : </translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1108"/>
        <source>Level 2 (standard) : </source>
        <translation type="unfinished">Niveau 2 (standard) : </translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1109"/>
        <source>privileges</source>
        <translation type="unfinished">Droits</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1110"/>
        <source>tree structure</source>
        <translation type="unfinished">Arborescence</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="644"/>
        <source>Simplified / Complete : </source>
        <translation type="unfinished">Simplifié / Complet : </translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="645"/>
        <source>Name : </source>
        <translation type="unfinished">Nom : </translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="646"/>
        <source>Comments : </source>
        <translation type="unfinished">Commentaires : </translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="647"/>
        <source>Password : </source>
        <translation type="unfinished">Mot de passe : </translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="648"/>
        <source>creation of roles : </source>
        <translation type="unfinished">Création de rôles : </translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="649"/>
        <source>database creation : </source>
        <translation type="unfinished">Création de bases de données : </translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="650"/>
        <source>super user : </source>
        <translation type="unfinished">Super utilisateur : </translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="651"/>
        <source>Inherits rights : </source>
        <translation type="unfinished">Héritage des droits : </translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="652"/>
        <source>Replications : </source>
        <translation type="unfinished">Réplication : </translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="654"/>
        <source>General</source>
        <translation type="unfinished">Général</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="655"/>
        <source>Rights</source>
        <translation type="unfinished">Attributs</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../bibli_ihm_asgard.py" line="674"/>
        <source>Good you have a update rôle !!</source>
        <translation type="unfinished">Rôle modifié !!</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="723"/>
        <source>No value changed</source>
        <translation type="unfinished">Aucune valeur modifiée</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="728"/>
        <source>ASGARD MANAGER : Warning</source>
        <translation type="unfinished">ASGARD MANAGER : Attention</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="862"/>
        <source>Information !!!</source>
        <translation type="unfinished">Information !!!</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1170"/>
        <source>New connexion</source>
        <translation type="unfinished">Nouveau rôle de connexion</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1171"/>
        <source>Creating a connexion with all of its attributes.</source>
        <translation type="unfinished">Création d&apos;un rôle de connexion avec l&apos;ensemble de ses attributs</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1175"/>
        <source>New group</source>
        <translation type="unfinished">Nouveau rôle de groupe</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1176"/>
        <source>Creating a group with all of its attributes.</source>
        <translation type="unfinished">Création d&apos;un rôle de groupe avec l&apos;ensemble de ses attributs</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="693"/>
        <source>name and password required</source>
        <translation type="unfinished">Nom et mot de passe obligatoire</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="696"/>
        <source>name required</source>
        <translation type="unfinished">Nom obligatoire</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="699"/>
        <source>password required</source>
        <translation type="unfinished">Mot de passe obligatoire</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="708"/>
        <source>The Name </source>
        <translation type="unfinished">Le nom </translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="708"/>
        <source> already exists</source>
        <translation type="unfinished"> existe déjà</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1180"/>
        <source>removing the connexion role</source>
        <translation type="unfinished">Suppression du rôle de connexion</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1181"/>
        <source>removing the connexion role.</source>
        <translation type="unfinished">Suppression du rôle de connexion</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1185"/>
        <source>removing the group role</source>
        <translation type="unfinished">Suppression du rôle de groupe</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1186"/>
        <source>removing the group role.</source>
        <translation type="unfinished">Suppression du rôle de groupe</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="653"/>
        <source>schema management : </source>
        <translation type="unfinished">Gestion des schémas : </translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="530"/>
        <source>Grant the &apos;CREATE&apos; right on the database and make the schema editor member role Z_ASGARD</source>
        <translation type="unfinished">Accorde le droit &apos;CREATE&apos; sur la base et rend le rôle membre de l&apos;editeur du schéma Z_ASGARD</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../bibli_asgard.py" line="1877"/>
        <source>Le rôle g_admin et les super-utilisateurs sont toujours habilités à gérer les schémas.</source>
        <translation type="unfinished">Le rôle g_admin et les super-utilisateurs sont toujours habilités à gérer les schémas.</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../bibli_asgard.py" line="1880"/>
        <source>Pour pouvoir déléguer la gestion des schémas, vous devez préalablement désigner un éditeur pour le schéma &quot;z_asgard&quot;.</source>
        <translation type="unfinished">Pour pouvoir déléguer la gestion des schémas, vous devez préalablement désigner un éditeur pour le schéma &quot;z_asgard&quot;.</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../bibli_asgard.py" line="1883"/>
        <source>En activant cette option, vous conférez au rôle le privilège CREATE sur la base et l&apos;appartenance au rôle éditeur du schéma &quot;z_asgard&quot;</source>
        <translation type="unfinished">En activant cette option, vous conférez au rôle le privilège CREATE sur la base et l&apos;appartenance au rôle éditeur du schéma &quot;z_asgard&quot;</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../bibli_asgard.py" line="1886"/>
        <source>Le rôle est l&apos;éditeur du schéma &quot;z_asgard&quot;. En activant cette option, vous lui conférez le privilège CREATE sur la base.</source>
        <translation type="unfinished">Le rôle est l&apos;éditeur du schéma &quot;z_asgard&quot;. En activant cette option, vous lui conférez le privilège CREATE sur la base.</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../bibli_asgard.py" line="1890"/>
        <source>Le rôle est déjà membre du rôle éditeur du schéma &quot;z_asgard&quot;. En activant cette option, vous lui conférez le privilège CREATE sur la base.</source>
        <translation type="unfinished">Le rôle est déjà membre du rôle éditeur du schéma &quot;z_asgard&quot;. En activant cette option, vous lui conférez le privilège CREATE sur la base.</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../bibli_asgard.py" line="1893"/>
        <source>Le rôle dispose déjà du privilège CREATE sur la base. En activant cette option, vous le rendez membre du rôle éditeur du schéma &quot;z_asgard&quot;.</source>
        <translation type="unfinished">Le rôle dispose déjà du privilège CREATE sur la base. En activant cette option, vous le rendez membre du rôle éditeur du schéma &quot;z_asgard&quot;.</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../bibli_asgard.py" line="1896"/>
        <source>En désactivant cette option, vous retirez au rôle le privilège CREATE sur la base et l&apos;appartenance au rôle éditeur du schéma &quot;z_asgard&quot;.</source>
        <translation type="unfinished">En désactivant cette option, vous retirez au rôle le privilège CREATE sur la base et l&apos;appartenance au rôle éditeur du schéma &quot;z_asgard&quot;.</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../bibli_asgard.py" line="1899"/>
        <source>Le rôle est l&apos;éditeur du schéma &quot;z_asgard&quot;. En désactivant cette option, vous lui retirez le privilège CREATE sur la base.</source>
        <translation type="unfinished">Le rôle est l&apos;éditeur du schéma &quot;z_asgard&quot;. En désactivant cette option, vous lui retirez le privilège CREATE sur la base.</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1190"/>
        <source>Revoke all rights of the role</source>
        <translation type="unfinished">Révoquer tous les droits du rôle</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1191"/>
        <source>Revokes all the rights of the role on the database objects, as well as its default privileges.</source>
        <translation type="unfinished">Révoque tous les droits du rôle sur les objets de la base, ainsi que ses privilèges par défaut.</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1195"/>
        <source>Revoke all rights of the groupe</source>
        <translation type="unfinished">Révoquer tous les droits du groupe</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1196"/>
        <source>Revokes all the rights of the groupe on the database objects, as well as its default privileges.</source>
        <translation type="unfinished">Révoque tous les droits du groupe sur les objets de la base, ainsi que ses privilèges par défaut</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1430"/>
        <source>Reset rights</source>
        <translation type="unfinished">Réinitialiser les droits</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1396"/>
        <source>Restores the standard rights of the producer, editor and reader to the diagram and the objects it contains.</source>
        <translation type="unfinished">Rétablit les droits standards du producteur, de l’éditeur et du lecteur sur le schéma et les objets qu’il contient.</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1400"/>
        <source>Move / Cut</source>
        <translation type="unfinished">Déplacer / Couper</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1401"/>
        <source>Select an object to change schema.</source>
        <translation type="unfinished">Sélectionne un objet à changer de schéma.</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1405"/>
        <source>Move / Paste</source>
        <translation type="unfinished">Déplacer / Coller</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1406"/>
        <source>Defines the new schema for the selected object. The rights are transferred from the producer, editor and reader of the starting schema to those of the target schema.</source>
        <translation type="unfinished">Définit le nouveau schéma de l&apos;objet sélectionné. Les droits sont transférés des producteur, éditeur et lecteur du schéma de départ à ceux du schéma cible.</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1410"/>
        <source>Cancel &quot;Move / Cut&quot;</source>
        <translation type="unfinished">Annuler le &quot;Déplacer / Couper&quot;</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1411"/>
        <source>Cancels the movement of the selected object.</source>
        <translation type="unfinished">Annule le déplacement de l&apos;objet sélectionné.</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="413"/>
        <source>Type</source>
        <translation type="unfinished">Type</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="414"/>
        <source>Circle</source>
        <translation type="unfinished">Cercle</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="415"/>
        <source>Bar</source>
        <translation type="unfinished">Barre</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="417"/>
        <source>Auto</source>
        <translation type="unfinished">Auto</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="418"/>
        <source>100 %</source>
        <translation type="unfinished">100 %</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="421"/>
        <source>Labels</source>
        <translation type="unfinished">Etiquettes</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="422"/>
        <source>Wording</source>
        <translation type="unfinished">Libellé</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="423"/>
        <source>Percentage</source>
        <translation type="unfinished">Pourcentage</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="424"/>
        <source>Value</source>
        <translation type="unfinished">Valeur</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="426"/>
        <source>Legende</source>
        <translation type="unfinished">Légende</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="427"/>
        <source>North</source>
        <translation type="unfinished">Nord</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="428"/>
        <source>West</source>
        <translation type="unfinished">Ouest</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="429"/>
        <source>East</source>
        <translation type="unfinished">Est</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="430"/>
        <source>South</source>
        <translation type="unfinished">Sud</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="432"/>
        <source>Title</source>
        <translation type="unfinished">Titre</translation>
    </message>
    <message>
        <location filename="../asgard_general_ui.py" line="433"/>
        <source>Animation</source>
        <translation type="unfinished">Animation</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1415"/>
        <source>Refer to ... </source>
        <translation type="unfinished">Référencer vers ...</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1416"/>
        <source>The scheme will be supported by ASGARD mechanisms. It is classified in the tree structure according to the choice of the active functional block in the submenu. The rights to the schema and its content are reset.</source>
        <translation type="unfinished">Le schéma sera pris en charge par les mécanismes d’ASGARD. Il est classé dans l’arborescence en fonction du choix du bloc fonctionnel actif dans le sous menu. Les droits sur le schéma et son contenu sont réinitialisés.</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1420"/>
        <source>Look for anomalies</source>
        <translation type="unfinished">Rechercher les anomalies</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1421"/>
        <source>Scans the schema and the objects it contains in search of missing or excess rights compared to the ASGARD standard.</source>
        <translation type="unfinished">Scanne le schéma et les objets qu&apos;il contient à la recherche de droits manquants ou excédentaires par rapport au standard d&apos;ASGARD.</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1425"/>
        <source>Referencing while retaining the rights</source>
        <translation type="unfinished">Référencer en conservant les droits</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1391"/>
        <source>The scheme will be supported by Asgard mechanisms. It is classified in the tree structure according to its prefix or, failing that, in the &apos;Others&apos; block, The rights to the schema and its content are reset.</source>
        <translation type="unfinished">Le schéma sera pris en charge par les mécanismes d’Asgard. Il est classé dans l’arborescence en fonction de son préfixe ou, à défaut, dans le bloc &apos;Autres&apos;. Les droits sur le schéma et son contenu sont réinitialisés.</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1426"/>
        <source>The scheme will be supported by Asgard mechanisms. It is classified in the tree structure according to its prefix or, failing that, in the &quot;Others&quot; block. The rights to the diagram and its content are retained.</source>
        <translation type="unfinished">Le schéma sera pris en charge par les mécanismes d’Asgard. Il est classé dans l’arborescence en fonction de son préfixe ou, à défaut, dans le bloc &apos;Autres&apos;. Les droits sur le schéma et son contenu sont conservés.</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1431"/>
        <source>Restores standard producer, publisher and reader rights to the object. .</source>
        <translation type="unfinished">Rétablit les droits standards du producteur, de l’éditeur et du lecteur sur l’objet.</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1210"/>
        <source>Reassign rights / Cut</source>
        <translation type="unfinished">Réaffecter les droits / Couper</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1211"/>
        <source>Transfers (Cut) all the rights of the role on the objects of the database, as well as its default privileges, for a designated role.</source>
        <translation type="unfinished">Transfère (Couper) tous les droits du rôle sur les objets de la base, ainsi que ses privilèges par défaut, pour un rôle désigné. ATTENTION : les droits hérités des groupes dont le rôle est membre ne sont pas concernés ! Seuls les droits attribués au rôle lui-même seront réaffectés.</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1215"/>
        <source>Reassign rights / Paste</source>
        <translation type="unfinished">Réaffecter les droits / Coller</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1216"/>
        <source>Transfers (Paste) all the rights of the role in memory on the database objects, as well as its default privileges, to a designated role.</source>
        <translation type="unfinished">Transfère (Coller) tous les droits du rôle en mémoire sur les objets de la base, ainsi que ses privilèges par défaut, à un rôle désigné. ATTENTION : les droits hérités des groupes dont le rôle est membre ne sont pas concernés ! Seuls les droits attribués au rôle lui-même seront réaffectés.</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1220"/>
        <source>Cancel Reassign Rights / Cut </source>
        <translation type="unfinished">Annuler le &quot;Réaffecter les droits / Couper&quot;</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1221"/>
        <source>Cancels the transfer of rights </source>
        <translation type="unfinished">Annule le transfère des droits.</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1435"/>
        <source>Replica</source>
        <translation type="unfinished">Répliquer</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1436"/>
        <source>Replicates the dataset for synchronization with the central database.</source>
        <translation type="unfinished">Réplique le jeu de données pour la synchronisation avec la base de données centrale.</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1440"/>
        <source>Dereplica</source>
        <translation type="unfinished">Dérépliquer</translation>
    </message>
    <message>
        <location filename="../bibli_ihm_asgard.py" line="1441"/>
        <source>Dereplicates the dataset for synchronization with the central database.</source>
        <translation type="unfinished">Déréplique le jeu de données pour la synchronisation avec la base de données centrale.</translation>
    </message>
</context>
<context>
    <name>colorbloc_ui</name>
    <message>
        <location filename="../colorbloc_ui.py" line="16"/>
        <source>Changing the colors of function blocks.</source>
        <translation type="unfinished">Changer les couleurs des blocs fonctionnels.</translation>
    </message>
    <message>
        <location filename="../colorbloc_ui.py" line="65"/>
        <source>  first plan  </source>
        <translation type="unfinished">  Couleurs premier plan  </translation>
    </message>
    <message>
        <location filename="../colorbloc_ui.py" line="70"/>
        <source>  second plan  </source>
        <translation type="unfinished">  Couleurs second plan  </translation>
    </message>
    <message>
        <location filename="../colorbloc_ui.py" line="214"/>
        <source>OK</source>
        <translation type="unfinished">OK</translation>
    </message>
    <message>
        <location filename="../colorbloc_ui.py" line="215"/>
        <source>Cancel</source>
        <translation type="unfinished">Annuler</translation>
    </message>
    <message>
        <location filename="../colorbloc_ui.py" line="300"/>
        <source>Confirmation</source>
        <translation type="unfinished">Confirmation</translation>
    </message>
    <message>
        <location filename="../colorbloc_ui.py" line="301"/>
        <source>You will save all your changes..</source>
        <translation type="unfinished">Vous allez sauvegarder toutes vos modifications des couleurs.</translation>
    </message>
    <message>
        <location filename="../colorbloc_ui.py" line="302"/>
        <source>Are you sure you want to continue ?</source>
        <translation type="unfinished">Etes-vous sûr de vouloir continuer ?</translation>
    </message>
    <message>
        <location filename="../colorbloc_ui.py" line="334"/>
        <source>Colors saved.</source>
        <translation type="unfinished">Couleurs sauvegardées</translation>
    </message>
    <message>
        <location filename="../colorbloc_ui.py" line="342"/>
        <source>Choose a color for the block : </source>
        <translation type="unfinished">Choix de la couleur du bloc fonctionnel : </translation>
    </message>
</context>
<context>
    <name>confirme_ui</name>
    <message>
        <location filename="../confirme_ui.py" line="189"/>
        <source>OK</source>
        <translation type="unfinished">OK</translation>
    </message>
    <message>
        <location filename="../confirme_ui.py" line="27"/>
        <source>Reset all rights.</source>
        <translation type="unfinished">Réinitialiser tous les droits</translation>
    </message>
    <message>
        <location filename="../confirme_ui.py" line="174"/>
        <source>Reminder of the definition of the action :</source>
        <translation type="unfinished">Rappel de la définition de l&apos;action :</translation>
    </message>
    <message>
        <location filename="../confirme_ui.py" line="175"/>
        <source>Confirm its execution</source>
        <translation type="unfinished">Confirmez son exécution</translation>
    </message>
    <message>
        <location filename="../confirme_ui.py" line="94"/>
        <source>Operation performed !!</source>
        <translation type="unfinished">Opération effectuée !!</translation>
    </message>
    <message>
        <location filename="../confirme_ui.py" line="190"/>
        <source>Cancel</source>
        <translation type="unfinished">Annuler</translation>
    </message>
    <message>
        <location filename="../confirme_ui.py" line="28"/>
        <source>By continuing, you will restore the standard rights of the roles designated as producer, editor and reader to all referenced schemas </source>
        <translation type="unfinished">En poursuivant, vous rétablirez les droits standards des rôles désignés comme producteur, l’éditeur et lecteur sur tous les schémas </translation>
    </message>
    <message>
        <location filename="../confirme_ui.py" line="29"/>
        <source>and the objects they contain. Excess rights will be revoked, missing rights reinstated. All rights assigned to other roles will be removed, </source>
        <translation type="unfinished">référencés et les objets qu&apos;ils contiennent. Les droits excédentaires seront révoqués, les droits manquants rétablis. </translation>
    </message>
    <message>
        <location filename="../confirme_ui.py" line="30"/>
        <source>as well as any default privileges defined on the schemas. WARNING: this function can be slow (a few minutes, or even tens of minutes)</source>
        <translation type="unfinished">Tous les droits attribués à d&apos;autres rôles seront supprimés, ainsi que les privilèges par défaut éventuellement définis sur les schémas. </translation>
    </message>
    <message>
        <location filename="../confirme_ui.py" line="31"/>
        <source> on a base comprising a very large number of diagrams or objects.</source>
        <translation type="unfinished">ATTENTION : cette fonction peut être lente (quelques minutes, voire dizaines de minutes) sur une base comportant un très grand nombre de schémas ou d&apos;objets.</translation>
    </message>
    <message>
        <location filename="../confirme_ui.py" line="46"/>
        <source>Reference all the diagrams in the database.</source>
        <translation type="unfinished">Référencer tous les schémas de la base.</translation>
    </message>
    <message>
        <location filename="../confirme_ui.py" line="47"/>
        <source>By continuing, you will proceed to the referencing of all the diagrams of the base still not supported by the mechanisms of ASGARD </source>
        <translation type="unfinished">En poursuivant, vous procéderez au référencement de tous les schémas de la base encore non pris en charge par les mécanismes d&apos;ASGARD </translation>
    </message>
    <message>
        <location filename="../confirme_ui.py" line="48"/>
        <source>(except system diagrams, public and, if it exists, topology). The diagrams will be classified in the tree structure according to their prefix or, </source>
        <translation type="unfinished">(hors schémas système, public et, s&apos;il existe, topology). Les schémas seront classés dans l&apos;arborescence en fonction de leur préfixe ou, </translation>
    </message>
    <message>
        <location filename="../confirme_ui.py" line="49"/>
        <source>failing that, in the &quot;Others&quot; block. The rights on the diagrams and the objects they contain will not be affected, you will then have the possibility </source>
        <translation type="unfinished">à défaut, dans le bloc &quot;Autres&quot;. Les droits sur les schémas et les objets qu&apos;ils contiennent ne seront pas affectés, vous aurez ensuite la possibilité </translation>
    </message>
    <message>
        <location filename="../confirme_ui.py" line="50"/>
        <source>to use the functions of ASGARD to reset the rights.</source>
        <translation type="unfinished">d&apos;utiliser les fonctionnalités d&apos;ASGARD pour la réinitialisation des droits.</translation>
    </message>
    <message>
        <location filename="../confirme_ui.py" line="53"/>
        <source>Import or repair the national nomenclature.</source>
        <translation type="unfinished">Importer ou réparer la nomenclature nationale.</translation>
    </message>
    <message>
        <location filename="../confirme_ui.py" line="54"/>
        <source>Imports national nomenclature schemas as inactive schemas. Repeating the operation restores the missing diagrams and resets the tree level labels for all the diagrams in the BOM.</source>
        <translation type="unfinished">Importe les schémas de la nomenclature nationale sous forme de schémas inactifs. Répéter l&apos;opération restaure les schémas manquants et réinitialise les libellés des niveaux d&apos;arborescence pour tous les schémas de la nomenclature.</translation>
    </message>
    <message>
        <location filename="../confirme_ui.py" line="57"/>
        <source>Install ASGARD on the base.</source>
        <translation type="unfinished">Installer ASGARD sur la base.</translation>
    </message>
    <message>
        <location filename="../confirme_ui.py" line="58"/>
        <source>By continuing, you will install the PostgreSQL ASGARD extension, version </source>
        <translation type="unfinished">En poursuivant, vous procéderez à l&apos;installation de l&apos;extension PostgreSQL ASGARD, version </translation>
    </message>
    <message>
        <location filename="../confirme_ui.py" line="60"/>
        <source> on database </source>
        <translation type="unfinished"> sur la base de données </translation>
    </message>
    <message>
        <location filename="../confirme_ui.py" line="64"/>
        <source>Update the ASGARD extension.</source>
        <translation type="unfinished">Mettre à jour l&apos;extension ASGARD.</translation>
    </message>
    <message>
        <location filename="../confirme_ui.py" line="65"/>
        <source>Continuing on, you will update the PostgreSQL ASGARD extension (current version </source>
        <translation type="unfinished">En poursuivant, vous procéderez à la mise à jour de l&apos;extension PostgreSQL ASGARD (version courante </translation>
    </message>
    <message>
        <location filename="../confirme_ui.py" line="67"/>
        <source>, target version</source>
        <translation type="unfinished">, version cible </translation>
    </message>
    <message>
        <location filename="../confirme_ui.py" line="69"/>
        <source>) on database </source>
        <translation type="unfinished">) sur la base de données </translation>
    </message>
    <message>
        <location filename="../confirme_ui.py" line="71"/>
        <source>. This action is irreversible.</source>
        <translation type="unfinished">. Cette action est irréversible.</translation>
    </message>
    <message>
        <location filename="../confirme_ui.py" line="74"/>
        <source>Uninstall the ASGARD extension.</source>
        <translation type="unfinished">Désinstaller l&apos;extension ASGARD.</translation>
    </message>
    <message>
        <location filename="../confirme_ui.py" line="75"/>
        <source>Continuing on, you will proceed to uninstall the PostgreSQL ASGARD extension on the database </source>
        <translation type="unfinished">En poursuivant, vous procéderez à la désinstallation de l&apos;extension PostgreSQL ASGARD sur la base de données </translation>
    </message>
    <message>
        <location filename="../confirme_ui.py" line="77"/>
        <source>. This action does not affect the rights attributed to the diagrams and objects of the database, but the information stored in the ASGARD management table (readers and editors designated for the diagrams and tree levels) will be permanently lost.</source>
        <translation type="unfinished">. Cette action n&apos;affecte pas les droits attribués sur les schémas et objets de la base, mais les informations stockées dans la table de gestion d&apos;ASGARD (lecteurs et éditeurs désignés pour les schémas et niveaux d&apos;arborescence) seront définitivement perdues.</translation>
    </message>
    <message>
        <location filename="../confirme_ui.py" line="23"/>
        <source>ASGARD extension not installed.</source>
        <translation type="unfinished">Extension ASGARD non installée</translation>
    </message>
    <message>
        <location filename="../confirme_ui.py" line="24"/>
        <source>The files required to install the ASGARD extension are missing. You have to install them manually.</source>
        <translation type="unfinished">Les fichiers nécessaires à l&apos;installation de l&apos;extension ASGARD sont absents. Vous devez les installer manuellement. Pour PostgreSQL 10 sous Windows &apos;C:\Program Files\PostgreSQL\10\share\extension&apos;, Pour une installation PostgreSQL 10 sous Linux, on aura plutôt : &apos;/usr/share/postgresql/10/extension&apos;</translation>
    </message>
    <message>
        <location filename="../confirme_ui.py" line="34"/>
        <source>Find all anomalies.</source>
        <translation type="unfinished">Rechercher toutes les anomalies.</translation>
    </message>
    <message>
        <location filename="../confirme_ui.py" line="35"/>
        <source>Scans referenced schemas and the objects they contain for missing or excess rights over the ASGARD standard.</source>
        <translation type="unfinished">Scanne les schémas référencés et les objets qu&apos;ils contiennent à la recherche de droits manquants ou excédentaires par rapport au standard d&apos;ASGARD.</translation>
    </message>
    <message>
        <location filename="../bibli_asgard.py" line="4282"/>
        <source>ASGARD MANAGER : Anomalies detected</source>
        <translation type="unfinished">ASGARD MANAGER : Anomalies détectées</translation>
    </message>
    <message>
        <location filename="../confirme_ui.py" line="205"/>
        <source>No anomalies detected.</source>
        <translation type="unfinished">Aucune anomalie détectée</translation>
    </message>
    <message>
        <location filename="../confirme_ui.py" line="220"/>
        <source>Information !!!</source>
        <translation type="unfinished">Information !!!</translation>
    </message>
    <message>
        <location filename="../confirme_ui.py" line="38"/>
        <source>Make all users members of g_consult.</source>
        <translation type="unfinished">Rendre tous les utilisateurs membres de g_consult</translation>
    </message>
    <message>
        <location filename="../confirme_ui.py" line="39"/>
        <source>By continuing, you will make all login roles that aren&apos;t already a member of the g_consult role, as recommended for proper functioning of ASGARD. g_consult is a consult role, intended to have read-only access to all public data. The connection role of a user must imperatively belong to g_consult so that he can launch the AsgardMenu plugin.</source>
        <translation type="unfinished">En poursuivant, vous rendrez membre du rôle g_consult tous les rôles de connexion qui ne le sont pas déjà, comme recommandé pour le bon fonctionnement d&apos;ASGARD. g_consult est un rôle de consultation, prévu pour accéder en lecture seule à toutes les données publiques. Le rôle de connexion d&apos;un utilisateur doit impérativement appartenir à g_consult pour qu&apos;il puisse lancer le plugin AsgardMenu.</translation>
    </message>
    <message>
        <location filename="../confirme_ui.py" line="43"/>
        <source>By continuing, you will refresh the names of the roles listed in the ASGARD management table (as they appear in the &quot;Schemas&quot; tab). This action does not affect the rights in any way, it only allows you to view the correct names when a role has been renamed, or deleted without first launching the &quot;Revoke all rights of the role / group&quot; action.</source>
        <translation type="unfinished">En poursuivant, vous rafraîchirez les noms des rôles répertoriés dans la table de gestion d&apos;ASGARD (tels qu&apos;ils apparaissent dans l&apos;onglet &quot;Schémas&quot;). Cette action n&apos;affecte en aucune façon les droits, elle permet seulement de visualiser les bons noms lorsqu&apos;un rôle a été renommé, ou supprimé sans lancement préalable de l&apos;action &quot;Révoquer tous les droits du rôle/groupe&quot;.</translation>
    </message>
    <message>
        <location filename="../confirme_ui.py" line="42"/>
        <source>Refresh the role names in the management table.</source>
        <translation type="unfinished">Rafraîchir les noms de rôles dans la table de gestion.</translation>
    </message>
    <message>
        <location filename="../confirme_ui.py" line="80"/>
        <source>Look for anomalies.</source>
        <translation type="unfinished">Rechercher les anomalies.</translation>
    </message>
    <message>
        <location filename="../confirme_ui.py" line="81"/>
        <source>Scans the schema and the objects it contains in search of missing or excess rights compared to the ASGARD standard.</source>
        <translation type="unfinished">Scanne le schéma et les objets qu&apos;il contient à la recherche de droits manquants ou excédentaires par rapport au standard d&apos;ASGARD.</translation>
    </message>
</context>
<context>
    <name>erreur_ui</name>
    <message>
        <location filename="../erreur_ui.py" line="143"/>
        <source>OK</source>
        <translation type="unfinished">OK</translation>
    </message>
    <message>
        <location filename="../erreur_ui.py" line="91"/>
        <source>AsgardManager has encountered an error.</source>
        <translation type="unfinished">AsgardManager a rencontré une erreur.</translation>
    </message>
    <message>
        <location filename="../erreur_ui.py" line="92"/>
        <source>Operation prohibited.</source>
        <translation type="unfinished">Opération interdite.</translation>
    </message>
    <message>
        <location filename="../erreur_ui.py" line="93"/>
        <source>ASGARD has encountered an error.</source>
        <translation type="unfinished">ASGARD a rencontré une erreur.</translation>
    </message>
    <message>
        <location filename="../erreur_ui.py" line="114"/>
        <source>Unreported errors</source>
        <translation type="unfinished">Erreurs non recencées</translation>
    </message>
    <message>
        <location filename="../erreur_ui.py" line="139"/>
        <source>To help improve the tool, report this anomaly to us on the </source>
        <translation type="unfinished">Pour contribuer à l&apos;amélioration de l&apos;outil, signalez-nous cette anomalie sur le </translation>
    </message>
</context>
</TS>
